var limit = Number(prompt('Enter limit for prime number series'));
var prime;
for (prime = 2; prime <= limit; prime++) {
	var f = 0;
	for (var i = 2; i < prime; i++) {
		if (prime % i == 0) {
			f++;
			break;
		}
	}
	if (f === 0) {
		console.log(`${prime} Is Prime Number`);
	}
}
