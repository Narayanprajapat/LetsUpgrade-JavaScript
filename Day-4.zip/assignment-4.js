var choice = Number(
	prompt(
		`1.Addtion\n2.Subtraction\n3.Multiplication\n4.Division\n5.Square root\n6.Percentage\nEnter Your Choice :`
	)
);
switch (choice) {
	case 1:
		var num1 = Number(prompt('Enter First Number : '));
		var num2 = Number(prompt('Enter Second Number : '));
		var add = num1 + num2;
		console.log('Addition : ', add);
		break;
	case 2:
		var num1 = Number(prompt('Enter First Number : '));
		var num2 = Number(prompt('Enter Second Number : '));
		var sub = num1 - num2;
		console.log('Subtraction : ', sub);
		break;
	case 3:
		var num1 = Number(prompt('Enter First Number : '));
		var num2 = Number(prompt('Enter Second Number : '));
		var mul = num1 * num2;
		console.log('Multiplication : ', mul);
		break;
	case 4:
		var num1 = Number(prompt('Enter First Number : '));
		var num2 = Number(prompt('Enter Second Number : '));
		var div = num1 / num2;
		console.log('Division : ', div);
		break;
	case 5:
		var num = Number(prompt('Enter Number : '));
		var sqrt = Math.sqrt(num);
		console.log(`${num} Is Square Root = ${sqrt}`);
		break;
	case 6:
		var max = Number(prompt('Enter Maximum Marks : '));
		var scoredMarks = Number(prompt('Enter Scored Marks : '));
		if (max > scoredMarks) {
			var per = (scoredMarks * 100) / max;
			console.log(`Percentage : ${scoredMarks}*100/${max} = ${per}`);
		}
		break;
	default:
		alert('Invalid Choice');
		break;
}
