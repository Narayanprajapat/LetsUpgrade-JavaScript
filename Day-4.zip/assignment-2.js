const student = {
	name: 'Helsinki',
	age: 24,
	projects: {
		diceGame: 'Two player dice game using JavaScript',
	},
};

const {
	name,
	age,
	projects: { diceGame },
} = student;

console.log(`Name : %c${name}`, `color:red`);
console.log(`Age : %c${age}`, `color:red`);
console.log(`Project : %c${diceGame}`, `color:red`);
