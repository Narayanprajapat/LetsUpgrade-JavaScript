var shoppingBasket = ['Fruits', 'Biscuit', 'Toys', 'Sports'];
console.log('shoppingBasket', shoppingBasket);
var shoppingList = [];
shoppingList.push(...shoppingBasket);
alert(' Add some new products into it. ');
shoppingList.push(prompt('Add Some Products'));
console.log('shoppingList', shoppingList);
