var salesForm = Number(prompt('Enter Your Sales Form '));
var commission;
if (0 < salesForm && salesForm <= 5000) {
	commission = (salesForm * 2) / 100;
	console.log(`${salesForm} Form commission 2% = ${commission}`);
} else if (5001 < salesForm && salesForm <= 10000) {
	commission = (salesForm * 5) / 100;
	console.log(`${salesForm} Form commission 5% = ${commission}`);
} else if (10001 < salesForm && salesForm <= 20000) {
	commission = (salesForm * 7) / 100;
	console.log(`${salesForm} Form commission 7% = ${commission}`);
} else if (salesForm > 20000) {
	commission = (salesForm * 10) / 100;
	console.log(`${salesForm} Form commission 10% = ${commission}`);
}
